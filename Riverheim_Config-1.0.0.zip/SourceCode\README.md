﻿# Riverheim Config - Source Code

Complete source code for the Riverheim Config mod.

## Build Command
```
dotnet msbuild RiverheimConfigTest.csproj /t:Rebuild /p:Configuration=Release
```

Output: bin\Release\RiverheimConfigTest.dll

## Files
- RiverheimConfigTest.cs - Main plugin code
- RiverheimConfigTest.csproj - Project file
- ILRepack.targets - Merges ServerSync into output DLL
- ServerSync.dll - Config synchronization library
